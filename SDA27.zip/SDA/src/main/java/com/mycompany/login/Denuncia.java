
package com.mycompany.login;

public class Denuncia {
    private int id;
    private String classificacao;
    private String descricao;
    
    public Denuncia(int id, String classificacao, String descricao){
        this.id = id;
        this.classificacao = classificacao;
        this.descricao = descricao;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getClassificacao() {
        return classificacao;
    }

    public void setClassificacao(String classificacao) {
        this.classificacao = classificacao;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
