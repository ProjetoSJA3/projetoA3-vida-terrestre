package com.mycompany.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DAO {
    public boolean existe (Usuario usuario) throws Exception{ 
     String sql = "SELECT * FROM tb_usuario WHERE login = ? AND senha  = ?"; 
     try (Connection conn = ConexaoBD.obtemConexao(); 
     PreparedStatement ps = conn.prepareStatement(sql)){ 
        ps.setString(1, usuario.getLogin()); 
        ps.setString(2, usuario.getSenha()); 
        try (ResultSet rs = ps.executeQuery()){ 
            return rs.next(); 
        }
     } 
   }
    public void adicionarCadastro (Cadastro cadastro) throws Exception{
        String sql = "INSERT INTO tb_cadastro (nome, numero, email) values (?,?,?)";
        try (Connection conn = ConexaoBD.obtemConexao();
            PreparedStatement ps = conn.prepareStatement(sql)){
            ps.setString(1, cadastro.getNome());
            ps.setInt(2, cadastro.getNumero());
            ps.setString(3, cadastro.getEmail());
            ps.execute();
        }
    }
    public void adicionar (Denuncia denuncia) throws Exception{
       String sql = "INSERT INTO tb_denuncias (categoria_denuncia, descricao) values (?,?)";
       try (Connection conn = ConexaoBD.obtemConexao();
               PreparedStatement ps = conn.prepareStatement(sql)){
           ps.setString(1, denuncia.getClassificacao());
           ps.setString(2, denuncia.getDescricao());
           ps.execute();
       }
    }
}
    


