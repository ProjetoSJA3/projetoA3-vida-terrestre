package com.mycompany.login;

public class Anonimo {
    private String nome;
    
    public Anonimo (String nome){
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
